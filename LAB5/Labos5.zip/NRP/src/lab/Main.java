package lab;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.rule.Rule;

public class Main {

	public static void main(String[] args) {
		String fileName = "fcl/konfiguracija.fcl";
		FIS fis = FIS.load(fileName, true);
		if (fis == null) {
		System.err.println("Can't load file: '" + fileName + "'");
		return;
		}
		fis.chart();
		
		fis.setVariable("kasalj", 16);
		fis.setVariable("temperatura", 43);
		fis.setVariable("glavobolja", 9);
		fis.setVariable("grlobolja", 1);
		fis.setVariable("crvenilo", 2);
		fis.setVariable("bol_u_plucima", 11);
		fis.setVariable("kihanje", 9);

		fis.evaluate();
		fis.getVariable("decision").chartDefuzzifier(true);
		System.out.println(fis);
		System.out.println("REZULTAT:");
		System.out.println(fis.getVariable("decision").getValue());
		for (Rule r : fis.getFunctionBlock("bolesti")
		.getFuzzyRuleBlock("pravila_bolesti").getRules()) {
		System.out.println(r);
		}
	}

}
